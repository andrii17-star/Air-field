import React, { useState, useEffect, useRef } from 'react';
import ApiService from "../services/ApiService";
import Map from './../elements/Map';

// API key of the google map
const GOOGLE_MAP_API_KEY = 'AIzaSyAOzKK06karbhzgCg9hmcSrpLT4O4UYoS0';

// load google map script
const loadGoogleMapScript = (callback) => {
  if (typeof window.google === 'object' && typeof window.google.maps === 'object') {
    callback();
  } else {
    const googleMapScript = document.createElement("script");
    googleMapScript.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAP_API_KEY}`;
    window.document.body.appendChild(googleMapScript);
    googleMapScript.addEventListener("load", callback);
  }
}

const Home = () => {


  const dataFetchedRef = useRef(false);
  const [loadMap, setLoadMap] = useState(false);
  const [coordinates, setCoordinates] = useState([]);

  const retrieveCoordinates = () => {
    ApiService.getAll()
      .then((response) => {
        setCoordinates(response.data);
        setLoadMap(true)
      })
      .catch((e) => {
        console.log(e);
      });
  };

  useEffect(() => {
    if (dataFetchedRef.current) return;
    dataFetchedRef.current = true;

    loadGoogleMapScript(() => {
      retrieveCoordinates()
    });
  }, []);

  return (
    <div>
      {!loadMap ? <div>Loading...</div> : <Map coordinates={coordinates} />}
    </div>
  )
}

export default Home