//import useState hook to create menu collapse state
import React, { useState } from 'react';

//import react pro sidebar components
import {
  ProSidebar,
  Menu,
  MenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarContent,
} from "react-pro-sidebar";

import { Link } from "react-router-dom";

//import icons from react icons
import { FiHome, FiLogOut } from "react-icons/fi";


//import sidebar css from react-pro-sidebar module and our custom css 
import "react-pro-sidebar/dist/css/styles.css";
import "./Header.css";


const Header = () => {

  const [activePage, setActivePage] = useState(null) ;

  function handleActive(event) {
    if (!event.target.classList.value.includes("active")) {
      event.target.classList.toggle('active') ;
      if (activePage)
        activePage.classList.remove("active") ;
      setActivePage(event.target) ;
    }
  }

  function handleCoordinates(event) {

    if (!event.target.classList.value.includes("btn-primary")) {
      event.target.classList.toggle('btn-primary') ;
      event.target.classList.remove("btn-outline-primary") ;
      document.getElementsByClassName('coordinate-table')[0].style.visibility = 'hidden';
    } else {
      event.target.classList.toggle('btn-outline-primary') ;
      event.target.classList.remove("btn-primary") ;
      document.getElementsByClassName('coordinate-table')[0].style.visibility = 'visible';
    }
    
  }

  return (
      <div id="header">
          {/* collapsed props to change menu size using menucollapse state */}
        <ProSidebar>
          <SidebarHeader>
            <div className="logotext">
              <p>Air Field Main</p>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <Menu iconShape="square">
              <MenuItem active={window.location.pathname === "/"} icon={<FiHome />} onClick={handleActive}>
                <Link to="/">Home</Link>
              </MenuItem>
              <div id="menu">       
                <div>Layers</div>
              </div>
            </Menu>
          </SidebarContent>
          <SidebarFooter>
            <Menu iconShape="square">
              <MenuItem>
                <button className='btn btn-outline-primary' onClick={handleCoordinates}>Coordinates</button>
              </MenuItem>
              <MenuItem icon={<FiLogOut />}>Logout</MenuItem>
            </Menu>
          </SidebarFooter>
        </ProSidebar>
      </div>
  );
};

export default Header;