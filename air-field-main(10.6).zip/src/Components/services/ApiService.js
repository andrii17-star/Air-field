import axios from "axios";


const baseURL = "http://alternative.ms/spiral_temp/ar-tool_data/markers_airfield.json";
// "https://markers-server.vercel.app/api";

const getAll = () => {
  return axios.get(baseURL);
};

const ApiService = {
  getAll
};

export default ApiService;
