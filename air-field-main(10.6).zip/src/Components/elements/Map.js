import React, { useState, useEffect, useRef } from 'react';
import DataTable from "react-data-table-component";
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { FiDelete } from "react-icons/fi";

// let STATE: boolean[]
const STATE = Object.create(null)

function getCenter(markers) {
  let lat = 0;
  let lng = 0;
  markers.forEach((marker) => {
    lat += parseFloat(marker.latitude);
    lng += parseFloat(marker.longitude);
  });
  lat = lat / markers.length;
  lng = lng / markers.length;
  return { lat, lng };
}

function clearMarkers(markers) {
  for (let m of markers) {
    // m.setMap(null);
    m.setVisible(false)
  }
}

function showMarkers(markers) {
  for (let m of markers) {
    // m.setMap(null);
    m.setVisible(true)
  }
}

const Map = (props) => {

  const [coordinates, setCoordinates] = useState([]);
  const prevMarkersRef = useRef([]);
  const dataFetchedRef = useRef(false);

  const googleMapRef = useRef(null);
  let googleMap = null, center = null, bounds = new window.google.maps.LatLngBounds();

  const deleteCoordinate = (row) => {

    confirmAlert({
      title: 'Confirm to delete',
      message: 'Are you sure to delete this marker?',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            let markerList = [...coordinates];
            var index = markerList.indexOf(row);

            if (index !== -1) {
              prevMarkersRef.current[index].setMap(null);
              prevMarkersRef.current.splice(index, 1);

              setCoordinates(markerList => 
                markerList.filter(marker => {
                  return marker.num !== row.num;
                }),
              );
          
              setMarker(coordinates);
            }
          }
        },
        {
          label: 'No',
          onClick: () => {

          }
        }
      ]
    });
  }
  
  const columns = [
    {
      id: 1,
      name: "ID",
      selector: (row) => row.num,
      sortable: true,
      reorder: true
    },
    {
      id: 2,
      name: "Type",
      selector: (row) => row.type,
      sortable: true,
      reorder: true
    },
    {
      id: 3,
      name: "Latitude",
      selector: (row) => row.latitude,
      sortable: true,
      reorder: true
    },
    {
      id: 4,
      name: "Longitude",
      selector: (row) => row.longitude,
      sortable: true,
      right: true,
      reorder: true
    },
    {
        button: true,
        cell: row => (
          <div className="App">
            <div className="openbtn text-center">
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => deleteCoordinate(row)}
              >
                 {<FiDelete />}
              </button>
            </div>
          </div>
        )
    }
  ];

  // initialize the google map
  const initGoogleMap = (center) => {
    return new window.google.maps.Map(googleMapRef.current, {
      center: center,
      zoom: 17,
      mapTypeId: 'satellite',
      disableDefaultUI: true,
    });
  }

  // create marker on google map
  const createMarker = (markerObj) => {
    let icon = 'blue';
    switch (markerObj.type) {
      case 'Marking':
        icon = 'red';
        break;
      case 'Lighting':
        icon = 'green';
        break;
      default:
        break;
    }
    let icon_url = `http://maps.google.com/mapfiles/ms/icons/${icon}-dot.png`;
    return new window.google.maps.Marker({
      position: { lat: markerObj.latitude, lng: markerObj.longitude },
      map: googleMap,
      icon: icon_url
    });
  }

  // list of the marker object along with icon

  useEffect(() => {
    if (dataFetchedRef.current) return;
    dataFetchedRef.current = true;

    const markerList = props.coordinates
    center = getCenter(markerList);
    clearMarkers(prevMarkersRef.current); 
    
    googleMap = initGoogleMap(center);
    googleMap.fitBounds(bounds); // the map to contain all markers

    setCoordinates(markerList);
    setMarker(markerList);

    const markersTypes = [...new Set(markerList.map(item => item.type))]

    composeLayerSwitcher(markersTypes, markerList)

  }, []);

  const setMarker = (markerList) => {

    markerList.map(x => {
      const marker = createMarker(x);
      bounds.extend(marker.position);
      prevMarkersRef.current.push(marker);
    });
  }

  const composeLayerSwitcher = (markerTypes, markerList) => {
    markerTypes.forEach(layerType => {
      const newDiv = document.createElement("label");

      let icon = 'blue';
      switch (layerType) {
        case 'Marking':
          icon = 'red';
          break;
        case 'Lighting':
          icon = 'green';
          break;
        default:
          break;
      }
      let icon_url = `http://maps.google.com/mapfiles/ms/icons/${icon}-dot.png`;

      const imgCont = document.createElement("img")
      imgCont.src = icon_url
      imgCont.style.cssText = 'height: 20px;';
      newDiv.appendChild(imgCont);
  
      // and give it some content
      const labelCont = document.createElement("div")
      labelCont.style.cssText += `display: flex; align-items: center`;
      newDiv.appendChild(labelCont);
      const colorDot = document.createElement("div")
      colorDot.style.cssText += `width: 10px; height: 10px; margin-right: 8px; border-radius: 8px;}; border: 1px solid white;`;
  
  
      const input = document.createElement("input")
      input.style.cssText += 'margin-left: 8px;';
      input.setAttribute("type", "checkbox")
      input.setAttribute("checked", "true")
      const newContent = document.createTextNode(layerType);
      
      labelCont.appendChild(colorDot);
      labelCont.appendChild(newContent);
      newDiv.appendChild(input);
      newDiv.style.cssText += 'padding:10px;cursor: pointer; display: flex; border-bottom: solid 1px #585656; align-items: center;justify-content: space-between;';
  
      newDiv.addEventListener('change', (event) => {
        STATE[layerType] = !STATE[layerType];

        for (let index = 0; index < markerList.length; index++) {
          const element = markerList[index];

          if(element.type == layerType) {
            var i = markerList.indexOf(element);
            
            if(STATE[layerType]) {
          
              clearMarkers([prevMarkersRef.current[i]])
            } else {
              showMarkers([prevMarkersRef.current[i]])
            }
          }
          
        }
      }); 
      
      const menuDiv = document.getElementById("menu");
      menuDiv.appendChild(newDiv);
    })
  }  

  return (
    <div>
      <div className='coordinate-table'>
        <DataTable 
            title="Coordinates"
            columns={columns}
            data={coordinates}
            defaultSortFieldId={1}
            pagination
            selectableRows
        />
      </div>
      <div
        ref={googleMapRef}
        style={{ height: '100vh' }}
      />
    </div>
  )
}

export default Map;