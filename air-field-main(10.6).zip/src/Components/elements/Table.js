import React, { useState, useEffect, useRef } from 'react';
import DataTable from "react-data-table-component";

import { FiDelete } from "react-icons/fi";

const Map = (props) => {

    const columns = [
        {
            id: 1,
            name: "ID",
            selector: (row) => row.num,
            sortable: true,
            reorder: true
        },
        {
            id: 2,
            name: "Name",
            selector: (row) => row.name,
            sortable: true,
            reorder: true
        },
        {
            id: 3,
            name: "Type",
            selector: (row) => row.type,
            sortable: true,
            reorder: true
        },
        {
            id: 4,
            name: "Latitude",
            selector: (row) => row.latitude,
            sortable: true,
            reorder: true
        },
        {
            id: 5,
            name: "Longitude",
            selector: (row) => row.longitude,
            sortable: true,
            right: true,
            reorder: true
        },
        {
            button: true,
            cell: row => (
                <div className="App">
                    <div className="openbtn text-center">
                        <button
                            type="button"
                            className="btn btn-primary"
                            onClick={() => deleteCoordinate(row)}
                        >
                            {<FiDelete />}
                        </button>
                    </div>
                </div>
            )
        }
    ];

    return (
        <div>
            <div className='coordinate-table'>
                <DataTable
                    title="Coordinates"
                    columns={columns}
                    data={coordinates}
                    defaultSortFieldId={1}
                    pagination
                    selectableRows
                />
            </div>
            <div
                ref={googleMapRef}
                style={{ height: '100vh' }}
            />
        </div>
    )
}

export default Map;
