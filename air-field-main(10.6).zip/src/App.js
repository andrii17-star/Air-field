import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import './App.css';

import Header from './Components/Header/Header'
import Home from './Components/Pages/Home'
import Coordinates from './Components/Pages/Coordinates'

function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <div className="App-Container">
          <Routes>
            <Route path='/' element={<Home/>} />
            <Route path='/Coordinates' element={<Coordinates/>} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;